﻿using codingTestingYanLynnAung.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace codingTestingYanLynnAung.Controllers
{
    public class VehicleController : Controller
    {
        // GET: Vehicle
        public ActionResult Index()
        {
            VehicleDBHandle dbhandle = new VehicleDBHandle();
            ModelState.Clear();
            return View(dbhandle.GetVehicle());
        }

        // GET: Vehicle/Details/5
        public ActionResult Details(int id)
        {
            VehicleDBHandle sdb = new VehicleDBHandle();
            return View(sdb.GetVehicle().Find(vmodel => vmodel.Id == id));
           
        }

        // GET: Vehicle/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Vehicle/Create
        [HttpPost]
        public ActionResult Create(Vehicle vmodel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    VehicleDBHandle sdb = new VehicleDBHandle();
                    if (sdb.AddVehicle(vmodel))
                    {
                        ViewBag.Message = "Vehicle Added Successfully";
                        ModelState.Clear();
                    }
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: Vehicle/Edit/5
        public ActionResult Edit(int id)
        {
            VehicleDBHandle sdb = new VehicleDBHandle();
            return View(sdb.GetVehicle().Find(vmodel => vmodel.Id == id));
        }

        // POST: Vehicle/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Vehicle vmodel)
        {
            try
            {
                VehicleDBHandle vdb = new VehicleDBHandle();
                vdb.UpdateDetails(vmodel);
                return RedirectToAction("Index",vdb.GetVehicle());
            }
            catch(InvalidCastException e)
            {
              
                return View();
            }
        }

        // GET: Vehicle/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                VehicleDBHandle vdb = new VehicleDBHandle();
                if (vdb.DeleteVehicle(id))
                {
                    ViewBag.AlertMsg = "Vehicle Deleted Successfully";
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

      
    }
}
