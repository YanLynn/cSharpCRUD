﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using codingTestingYanLynnAung.Models;
using System.Configuration;
using System.Data.SqlClient;

namespace codingTestingYanLynnAung.Controllers
{


    public class UserLoginController : Controller
    {
        // GET: UserLogin
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(LoginClass lc)
        {
            string mainconn = ConfigurationManager.ConnectionStrings["tmsdb"].ConnectionString;
            SqlConnection sqlconn = new SqlConnection(mainconn);
            string sqlquery = "select UserName,Password from [dbo].[UserProfile] where UserName=@UserName and Password=@Password";
            sqlconn.Open();
            SqlCommand sqlcomm = new SqlCommand(sqlquery,sqlconn);
            sqlcomm.Parameters.AddWithValue("@UserName", lc.UserName);
            sqlcomm.Parameters.AddWithValue("@Password", lc.Password);
            SqlDataReader sdr = sqlcomm.ExecuteReader();
            if (sdr.Read())
            {
                Session["username"] = lc.UserName.ToString();
                VehicleDBHandle dbhandle = new VehicleDBHandle();
                ModelState.Clear();
                return Redirect("Vehicle");

            }
            else
            {
                ViewBag["Message"] = "User Login Failed!";
            }
            sqlconn.Close();
            return View();
        }

    }
}