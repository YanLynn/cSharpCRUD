﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace codingTestingYanLynnAung.Models
{

    public class LoginClass
    {
        [Required(ErrorMessage = "User Name is required.")]
        [Display(Name ="Enter Username")]
        public string UserName { get; set; }



        [Required(ErrorMessage = "Password is required.")]
        [Display(Name = "Enter Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}