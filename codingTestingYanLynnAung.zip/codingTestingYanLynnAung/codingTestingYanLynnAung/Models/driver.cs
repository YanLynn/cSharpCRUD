﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace codingTestingYanLynnAung.Models
{
    public class driver
    {
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Required(ErrorMessage = "User Name is required.")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Full Name is required.")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "License no is required.")]
        public string LicenseNo { get; set; }


        [Required(ErrorMessage = "vehicle_id is required.")]
        public string Vehicle_id { get; set; }
        public List<Vehicle> Vehicle { get; set; }

        [Display(Name = "Plate_no")]
        public string Plate_no { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public string Date_created { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public string Date_updated { get; set; }
    }
}