﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace codingTestingYanLynnAung.Models
{
    public class VehicleDBHandle
    {
        private SqlConnection con;

        private void connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["tmsdb"].ToString();
            con = new SqlConnection(constring);
        }


        public bool AddVehicle(Vehicle vmodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("AddNewVehicle", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Plate_no", vmodel.Plate_no);
            cmd.Parameters.AddWithValue("@Vehicle_type", vmodel.Vehicle_type);
            cmd.Parameters.AddWithValue("@Date_created", DateTime.Now);
            cmd.Parameters.AddWithValue("@Date_updated", DateTime.Now);


            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        public List<Vehicle> GetVehicle()
        {
            connection();
            List<Vehicle> VehicleList = new List<Vehicle>();

            SqlCommand cmd = new SqlCommand("GetVehicleDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                VehicleList.Add(
                    new Vehicle
                    {
                        Id = Convert.ToInt32(dr["id"]),
                        Plate_no = Convert.ToString(dr["Plate_no"]),
                        Vehicle_type = Convert.ToString(dr["Vehicle_type"]),
                        Date_created = Convert.ToString(dr["Date_created"]),
                        Date_updated = Convert.ToString(dr["Date_created"]),
                    });
            }
            return VehicleList;
        }

        public bool UpdateDetails(Vehicle vmodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("UpdateVehicleDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@vId", vmodel.Id);
            cmd.Parameters.AddWithValue("@Plate_no", vmodel.Plate_no);
            cmd.Parameters.AddWithValue("@Vehicle_type", vmodel.Vehicle_type);
            cmd.Parameters.AddWithValue("@Date_created", DateTime.Now);
            cmd.Parameters.AddWithValue("@Date_update", DateTime.Now);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        public bool DeleteVehicle(int id)
        {
            connection();
            SqlCommand cmd = new SqlCommand("DeleteVehicle", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@vID", id);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }
    }
}