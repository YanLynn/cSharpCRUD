﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace codingTestingYanLynnAung.Models
{
    public class DriverDBHandle
    {
        private SqlConnection con;

        private void connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["tmsdb"].ToString();
            con = new SqlConnection(constring);
        }


        public bool AddDriver(driver dmodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("AddNewDrivers", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@UserName", dmodel.UserName);
            cmd.Parameters.AddWithValue("@FullName", dmodel.FullName);
            cmd.Parameters.AddWithValue("@LicenseNo", dmodel.LicenseNo);
            cmd.Parameters.AddWithValue("@vehicle_id", dmodel.Vehicle_id);
            cmd.Parameters.AddWithValue("@date_created", DateTime.Now);
            cmd.Parameters.AddWithValue("@date_updated", DateTime.Now);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        public List<driver> GetDrivers()
        {
            connection();
            List<driver> driversList = new List<driver>();

            SqlCommand cmd = new SqlCommand("GetDriversDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                driversList.Add(
                    new driver
                    {
                        Id = Convert.ToInt32(dr["id"]),
                        UserName = Convert.ToString(dr["user_name"]),
                        FullName = Convert.ToString(dr["full_name"]),
                        LicenseNo = Convert.ToString(dr["license_no"]),
                        Vehicle_id = Convert.ToString(dr["vehicle_id"]),
                        Plate_no = Convert.ToString(dr["Plate_no"]),
                        Date_created = Convert.ToString(dr["date_created"]),
                        Date_updated = Convert.ToString(dr["date_update"]),
                    });
            }
            return driversList;
        }

        public bool UpdateDetails(driver dmodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("UpdateDriversDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@driverID", dmodel.Id);
            cmd.Parameters.AddWithValue("@user_name", dmodel.UserName);
            cmd.Parameters.AddWithValue("@full_name", dmodel.FullName);
            cmd.Parameters.AddWithValue("@license_no", dmodel.LicenseNo);
            cmd.Parameters.AddWithValue("@vehicle_id", dmodel.Vehicle_id);
            cmd.Parameters.AddWithValue("@date_created", DateTime.Now);
            cmd.Parameters.AddWithValue("@date_updated", DateTime.Now);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        public bool DeleteDrivers(int id)
        {
            connection();
            SqlCommand cmd = new SqlCommand("DeleteDrivers", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@DriverID", id);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }
    }
}